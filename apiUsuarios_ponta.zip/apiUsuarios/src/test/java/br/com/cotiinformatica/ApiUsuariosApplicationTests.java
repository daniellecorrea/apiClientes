package br.com.cotiinformatica;

import static org.assertj.core.api.Assertions.fail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiUsuariosApplicationTests {

	@Test
	public void criarUsuarioTest() {
		fail("Não implementado.");
	}

	@Test
	public void autenticarUsuarioTest() {
		fail("Não implementado.");
	}

}
